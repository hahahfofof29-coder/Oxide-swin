# SWIN OXIDE — Standalone Android project

Большое чёрно-зелёное ImGui-приложение для Android. Не overlay поверх игры.

## Реализовано
- Отдельное запускаемое приложение на NativeActivity.
- Большое меню с вкладками ESP / AIM / SETTINGS / INFO.
- Рабочие checkbox, sliders, combo.
- Обработка Android touch input через ImGui Android backend.
- Сохранение настроек в приватный файл приложения `swin_settings.ini`.
- Загрузка настроек при следующем запуске.
- Сброс настроек к значениям по умолчанию.
- C++17, Dear ImGui 1.91.9b, Android NDK, OpenGL ES 3.

## Сборка APK
Требуется Android Studio, JDK 17, Android SDK Platform 35, NDK и CMake 3.22.1.
1. Откройте корневую папку `SwinOxideMenu-Standalone`.
2. Дождитесь Gradle Sync. CMake скачает Dear ImGui из официального GitHub-репозитория, поэтому при первой сборке нужен интернет.
3. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Для установки на телефон можно подключить TECNO POVA 7 5G по USB с включённой отладкой USB и нажать Run.

## Важно
Это самостоятельное приложение-настройщик. Элементы ESP/AIM являются рабочими настройками интерфейса и сохраняются между запусками, но не подключаются к Oxide, не читают память игры и не управляют прицелом. Для игровых функций необходим поддерживаемый игрой API или собственная тестовая сцена.

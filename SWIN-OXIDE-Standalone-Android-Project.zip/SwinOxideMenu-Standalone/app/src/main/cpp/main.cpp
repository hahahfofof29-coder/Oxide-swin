#include <android/log.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "SwinOxide", __VA_ARGS__)

struct Settings {
    bool espEnabled = false;
    bool boxEsp = true;
    bool skeletonEsp = false;
    bool nameEsp = true;
    bool distanceEsp = true;
    bool healthEsp = true;
    bool aimAssist = false;
    bool fovCircle = true;
    float maxDistance = 250.0f;
    float fov = 120.0f;
    float aimSmooth = 7.0f;
    int aimBone = 0;
    bool fpsCounter = true;
    float uiScale = 1.0f;
};

struct AppState {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0;
    int height = 0;
    bool initialized = false;
    bool showMenu = true;
    bool settingsDirty = false;
    std::string settingsPath;
    Settings cfg;
};

static AppState g;
static ImGuiStyle g_baseStyle;

static void SaveSettings() {
    if (g.settingsPath.empty()) return;
    FILE* f = std::fopen(g.settingsPath.c_str(), "w");
    if (!f) return;
    const Settings& s = g.cfg;
    std::fprintf(f,
        "espEnabled=%d\nboxEsp=%d\nskeletonEsp=%d\nnameEsp=%d\ndistanceEsp=%d\nhealthEsp=%d\n"
        "aimAssist=%d\nfovCircle=%d\nmaxDistance=%.3f\nfov=%.3f\naimSmooth=%.3f\naimBone=%d\n"
        "fpsCounter=%d\nuiScale=%.3f\n",
        s.espEnabled, s.boxEsp, s.skeletonEsp, s.nameEsp, s.distanceEsp, s.healthEsp,
        s.aimAssist, s.fovCircle, s.maxDistance, s.fov, s.aimSmooth, s.aimBone,
        s.fpsCounter, s.uiScale);
    std::fclose(f);
    g.settingsDirty = false;
}

static void LoadSettings() {
    if (g.settingsPath.empty()) return;
    FILE* f = std::fopen(g.settingsPath.c_str(), "r");
    if (!f) return;

    char line[128];
    while (std::fgets(line, sizeof(line), f)) {
        char key[64] = {};
        char value[64] = {};
        if (std::sscanf(line, "%63[^=]=%63s", key, value) != 2) continue;
        const int b = std::atoi(value);
        const float n = std::strtof(value, nullptr);
        if (!std::strcmp(key, "espEnabled")) g.cfg.espEnabled = b != 0;
        else if (!std::strcmp(key, "boxEsp")) g.cfg.boxEsp = b != 0;
        else if (!std::strcmp(key, "skeletonEsp")) g.cfg.skeletonEsp = b != 0;
        else if (!std::strcmp(key, "nameEsp")) g.cfg.nameEsp = b != 0;
        else if (!std::strcmp(key, "distanceEsp")) g.cfg.distanceEsp = b != 0;
        else if (!std::strcmp(key, "healthEsp")) g.cfg.healthEsp = b != 0;
        else if (!std::strcmp(key, "aimAssist")) g.cfg.aimAssist = b != 0;
        else if (!std::strcmp(key, "fovCircle")) g.cfg.fovCircle = b != 0;
        else if (!std::strcmp(key, "maxDistance")) g.cfg.maxDistance = std::clamp(n, 25.0f, 1000.0f);
        else if (!std::strcmp(key, "fov")) g.cfg.fov = std::clamp(n, 10.0f, 360.0f);
        else if (!std::strcmp(key, "aimSmooth")) g.cfg.aimSmooth = std::clamp(n, 1.0f, 20.0f);
        else if (!std::strcmp(key, "aimBone")) g.cfg.aimBone = std::clamp(b, 0, 3);
        else if (!std::strcmp(key, "fpsCounter")) g.cfg.fpsCounter = b != 0;
        else if (!std::strcmp(key, "uiScale")) g.cfg.uiScale = std::clamp(n, 0.8f, 1.3f);
    }
    std::fclose(f);
}

static bool InitEgl(ANativeWindow* window) {
    g.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g.display == EGL_NO_DISPLAY || !eglInitialize(g.display, nullptr, nullptr)) return false;

    const EGLint attrs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE
    };
    EGLConfig config = nullptr;
    EGLint count = 0;
    if (!eglChooseConfig(g.display, attrs, &config, 1, &count) || count == 0) return false;

    EGLint format = 0;
    eglGetConfigAttrib(g.display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(window, 0, 0, format);

    const EGLint contextAttrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    g.context = eglCreateContext(g.display, config, EGL_NO_CONTEXT, contextAttrs);
    g.surface = eglCreateWindowSurface(g.display, config, window, nullptr);
    if (g.context == EGL_NO_CONTEXT || g.surface == EGL_NO_SURFACE) return false;
    if (!eglMakeCurrent(g.display, g.surface, g.surface, g.context)) return false;

    eglQuerySurface(g.display, g.surface, EGL_WIDTH, &g.width);
    eglQuerySurface(g.display, g.surface, EGL_HEIGHT, &g.height);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();
    style.ScaleAllSizes(1.12f);
    style.WindowRounding = 12.0f;
    style.FrameRounding = 7.0f;
    style.GrabRounding = 7.0f;
    style.WindowBorderSize = 1.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.025f, 0.035f, 0.029f, 0.99f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.08f, 0.42f, 0.18f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.065f, 0.105f, 0.075f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.08f, 0.28f, 0.13f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.04f, 0.32f, 0.12f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.08f, 0.52f, 0.19f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.20f, 1.0f, 0.40f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.16f, 0.88f, 0.34f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.06f, 0.30f, 0.13f, 1.0f);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.04f, 0.18f, 0.08f, 1.0f);
    style.Colors[ImGuiCol_TabSelected] = ImVec4(0.05f, 0.42f, 0.15f, 1.0f);
    g_baseStyle = style;
    style = g_baseStyle;
    style.ScaleAllSizes(g.cfg.uiScale);

    ImGui_ImplAndroid_Init(window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    g.initialized = true;
    return true;
}

static void ShutdownEgl() {
    if (g.initialized) {
        SaveSettings();
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
        g.initialized = false;
    }
    if (g.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(g.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (g.context != EGL_NO_CONTEXT) eglDestroyContext(g.display, g.context);
        if (g.surface != EGL_NO_SURFACE) eglDestroySurface(g.display, g.surface);
        eglTerminate(g.display);
    }
    g.display = EGL_NO_DISPLAY;
    g.context = EGL_NO_CONTEXT;
    g.surface = EGL_NO_SURFACE;
}

static void MarkChanged(bool changed) {
    if (changed) {
        g.settingsDirty = true;
        SaveSettings();
    }
}

static void DrawMenu() {
    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowSize(ImVec2(560.0f, 760.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(24.0f, 36.0f), ImGuiCond_FirstUseEver);

    if (ImGui::Begin("SWIN OXIDE  |  CONTROL PANEL", nullptr,
                     ImGuiWindowFlags_NoCollapse)) {
        ImGui::TextColored(ImVec4(0.20f, 1.0f, 0.40f, 1.0f), "SWIN OXIDE");
        ImGui::SameLine();
        ImGui::TextDisabled("  SURVIVAL ISLAND");
        ImGui::Separator();

        if (ImGui::BeginTabBar("main_tabs", ImGuiTabBarFlags_FittingPolicyScroll)) {
            if (ImGui::BeginTabItem("ESP")) {
                MarkChanged(ImGui::Checkbox("Enable ESP", &g.cfg.espEnabled));
                ImGui::BeginDisabled(!g.cfg.espEnabled);
                MarkChanged(ImGui::Checkbox("Box ESP", &g.cfg.boxEsp));
                MarkChanged(ImGui::Checkbox("Skeleton ESP", &g.cfg.skeletonEsp));
                MarkChanged(ImGui::Checkbox("Name ESP", &g.cfg.nameEsp));
                MarkChanged(ImGui::Checkbox("Distance ESP", &g.cfg.distanceEsp));
                MarkChanged(ImGui::Checkbox("Health ESP", &g.cfg.healthEsp));
                if (ImGui::SliderFloat("Max distance", &g.cfg.maxDistance, 25.0f, 1000.0f, "%.0f m")
                    && ImGui::IsItemDeactivatedAfterEdit()) MarkChanged(true);
                ImGui::EndDisabled();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("AIM")) {
                MarkChanged(ImGui::Checkbox("Aim Assist", &g.cfg.aimAssist));
                ImGui::BeginDisabled(!g.cfg.aimAssist);
                MarkChanged(ImGui::Checkbox("FOV Circle", &g.cfg.fovCircle));
                if (ImGui::SliderFloat("FOV", &g.cfg.fov, 10.0f, 360.0f, "%.0f")
                    && ImGui::IsItemDeactivatedAfterEdit()) MarkChanged(true);
                if (ImGui::SliderFloat("Aim Smooth", &g.cfg.aimSmooth, 1.0f, 20.0f, "%.1f")
                    && ImGui::IsItemDeactivatedAfterEdit()) MarkChanged(true);
                const char* bones[] = { "Head", "Neck", "Chest", "Body" };
                MarkChanged(ImGui::Combo("Aim Bone", &g.cfg.aimBone, bones, IM_ARRAYSIZE(bones)));
                ImGui::EndDisabled();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("SETTINGS")) {
                MarkChanged(ImGui::Checkbox("FPS counter", &g.cfg.fpsCounter));
                if (ImGui::SliderFloat("UI scale", &g.cfg.uiScale, 0.8f, 1.3f, "%.2fx")) {
                    ImGui::GetStyle() = g_baseStyle;
                    ImGui::GetStyle().ScaleAllSizes(g.cfg.uiScale);
                    if (ImGui::IsItemDeactivatedAfterEdit()) MarkChanged(true);
                }
                if (ImGui::Button("SAVE SETTINGS", ImVec2(-1.0f, 48.0f))) SaveSettings();
                if (ImGui::Button("RESET DEFAULTS", ImVec2(-1.0f, 48.0f))) {
                    g.cfg = Settings{};
                    SaveSettings();
                }
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("INFO")) {
                ImGui::Text("Standalone Android control panel");
                ImGui::Text("Renderer: OpenGL ES 3");
                ImGui::Text("Screen: %d x %d", g.width, g.height);
                if (g.cfg.fpsCounter) ImGui::Text("FPS: %.1f", io.Framerate);
                ImGui::Separator();
                ImGui::TextWrapped("Settings are saved in this app's private storage and restored on next launch.");
                ImGui::TextWrapped("ESP and Aim controls are configuration UI only. They do not read or modify Oxide game data.");
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        ImGui::Separator();
        ImGui::TextDisabled("C++17  |  IMGUI  |  ANDROID NDK");
    }
    ImGui::End();
}

static int32_t HandleInput(android_app*, AInputEvent* event) {
    if (!g.initialized) return 0;
    return ImGui_ImplAndroid_HandleInputEvent(event) ? 1 : 0;
}

static void HandleCmd(android_app* app, int32_t cmd) {
    if (cmd == APP_CMD_INIT_WINDOW && app->window && !g.initialized) {
        if (!InitEgl(app->window)) LOGE("EGL initialization failed");
    } else if (cmd == APP_CMD_TERM_WINDOW) {
        ShutdownEgl();
    }
}

void android_main(android_app* app) {
    app->onAppCmd = HandleCmd;
    app->onInputEvent = HandleInput;
    g.settingsPath = std::string(app->activity->internalDataPath) + "/swin_settings.ini";
    LoadSettings();

    while (true) {
        int events = 0;
        android_poll_source* source = nullptr;
        while (ALooper_pollAll(g.initialized ? 0 : -1, nullptr, &events,
                               reinterpret_cast<void**>(&source)) >= 0) {
            if (source) source->process(app, source);
            if (app->destroyRequested) {
                ShutdownEgl();
                return;
            }
        }
        if (!g.initialized) continue;

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();
        DrawMenu();
        ImGui::Render();

        glViewport(0, 0, g.width, g.height);
        glClearColor(0.018f, 0.027f, 0.021f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        eglSwapBuffers(g.display, g.surface);
    }
}
